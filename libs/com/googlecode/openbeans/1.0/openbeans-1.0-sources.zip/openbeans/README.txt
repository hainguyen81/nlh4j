
OpenBeans is for Android.

OpenBeans is simply a redistribution of the java.beans package from the Apache Harmony project, which is an open source implementation of Java SE.  The only modification to the Harmony code is that the package name has been changed from java.beans to com.googlecode.openbeans.  This was done to support the Android environment which does not include java.beans in it's core libraries.